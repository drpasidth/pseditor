import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from django.test import TestCase

from . import approvals, ptyterm, shell
from .models import Agent, Workspace


class FakeResp:
    def __init__(self, data, status=200):
        self._data, self.status_code, self.text = data, status, json.dumps(data)

    def json(self):
        return self._data


def stream_events(resp):
    body = b"".join(resp.streaming_content).decode()
    return [json.loads(l) for l in body.splitlines() if l.strip()]


class Human(threading.Thread):
    """Plays the user clicking Approve/Deny. Only touches the in-memory approval registry (no DB)."""

    def __init__(self, answers, check=None):
        super().__init__(daemon=True)
        self.answers = list(answers)   # "allow" | "deny" | ("deny", reason) | "stop"
        self.check = check             # called with (approval) at the moment the request is shown
        self.seen = []
        self.halt = False

    def run(self):
        done = set()
        while not self.halt:
            with approvals._lock:
                todo = [a for a in approvals._pending.values() if a.decision is None and a.id not in done]
            for a in todo:
                done.add(a.id)
                self.seen.append((a.name, a.arguments))
                if self.check:
                    self.check(a)
                ans = self.answers.pop(0) if self.answers else "deny"
                ans, reason = ans if isinstance(ans, tuple) else (ans, "")
                if ans == "stop":
                    approvals.cancel_session(a.session_id)
                else:
                    approvals.decide(a.id, ans, reason)
            time.sleep(0.02)


class EditorTests(TestCase):
    def setUp(self):
        # Agent tests below run unattended; the approval gate has its own tests that switch it back on.
        no_gate = self.settings(PSEDITOR_REQUIRE_APPROVAL=False)
        no_gate.enable()
        self.addCleanup(no_gate.disable)
        Agent.objects.all().delete()  # drop the OpenRouter agent seeded by migration 0003
        self.extra_shells = []
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "hello.py").write_bytes(b"print('hi')\n")
        r = self.client.post("/api/workspaces", json.dumps({"path": str(self.root)}),
                             content_type="application/json")
        self.ws = r.json()["id"]

    def tearDown(self):
        import time
        shell.reset(self.ws)
        ptyterm.kill_session(self.ws)
        for s in self.extra_shells:
            s.kill()
        for attempt in range(20):  # Windows releases a killed process's cwd a moment later
            try:
                self.tmp.cleanup()
                break
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.25)

    def j(self, method, url, data=None):
        return getattr(self.client, method)(url, json.dumps(data or {}), content_type="application/json")

    # -- files -------------------------------------------------------------
    def test_index_and_bootstrap(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        html = r.content.decode()
        self.assertRegex(html, r"app\.js\?v=\d+")   # cache-busting so browsers don't run a stale UI
        self.assertRegex(html, r"app\.css\?v=\d+")
        self.assertIn("no-cache", r["Cache-Control"])
        self.assertEqual(len(self.client.get("/api/bootstrap").json()["workspaces"]), 1)

    def test_file_crud(self):
        base = f"/api/ws/{self.ws}/file"
        tree = self.client.get(f"/api/ws/{self.ws}/tree").json()["entries"]
        self.assertEqual([e["name"] for e in tree], ["hello.py"])
        self.assertEqual(self.client.get(base, {"path": "hello.py"}).json()["content"], "print('hi')\n")
        self.assertEqual(self.j("put", base, {"path": "pkg/mod.py", "content": "x = 1\n"}).status_code, 200)
        self.assertEqual((self.root / "pkg" / "mod.py").read_bytes(), b"x = 1\n")
        self.assertEqual(self.j("patch", base, {"path": "pkg/mod.py", "new_path": "pkg/m2.py"}).status_code, 200)
        self.assertTrue((self.root / "pkg" / "m2.py").exists())
        self.assertEqual(self.j("delete", base, {"path": "pkg"}).status_code, 200)
        self.assertFalse((self.root / "pkg").exists())

    def test_path_traversal_blocked(self):
        base = f"/api/ws/{self.ws}/file"
        self.assertEqual(self.client.get(base, {"path": "../secret.txt"}).status_code, 400)
        r = self.j("put", base, {"path": "../evil.txt", "content": "x"})
        self.assertEqual(r.status_code, 400)
        self.assertFalse((self.root.parent / "evil.txt").exists())

    def test_search(self):
        r = self.j("post", f"/api/ws/{self.ws}/search", {"query": "print"})
        self.assertEqual(r.json()["results"][0]["path"], "hello.py")

    # -- terminal (persistent real shell) -------------------------------------
    def term(self, command=""):
        return self.j("post", f"/api/ws/{self.ws}/terminal", {"command": command}).json()

    def test_terminal_prompt_is_real_path_and_cd_is_unrestricted(self):
        r = self.term()  # no command: just the prompt
        self.assertEqual(r["prompt"], str(self.root.resolve()) + ">")
        self.assertNotIn(self.root.name + " >", r["prompt"])
        r = self.term("echo pseditor-ok")
        self.assertIn("pseditor-ok", r["output"])
        (self.root / "sub").mkdir()
        r = self.term("cd sub")
        self.assertEqual(r["cwd"], str((self.root / "sub").resolve()))
        self.assertTrue(r["prompt"].endswith("sub>"))
        r = self.term("cd ..")
        self.assertEqual(r["cwd"], str(self.root.resolve()))
        # not confined to the workspace: go to the parent and to the drive root
        parent = self.root.resolve().parent
        self.assertEqual(self.term("cd ..")["cwd"], str(parent))
        anchor = Path(parent.anchor)
        self.assertEqual(self.term(f'cd "{anchor}"')["cwd"], str(anchor))
        self.assertEqual(self.term(f'cd "{self.root}"')["cwd"], str(self.root.resolve()))

    def test_terminal_state_persists_and_reports_exit_codes(self):
        if shell.IS_WIN:
            self.term("$x = 41")
            self.assertIn("42", self.term("$x + 1")["output"])
            self.term("$env:PSE_TEST = 'abc'")
            self.assertIn("abc", self.term("$env:PSE_TEST")["output"])
            (self.root / "sub").mkdir()
            self.assertIn("sub", self.term("ls")["output"])
            self.assertEqual(self.term('python -c "import sys; sys.exit(3)"')["exit_code"], 3)
            bad = self.term("nosuchcommand-xyz")
            self.assertNotEqual(bad["exit_code"], 0)
            self.assertIn("nosuchcommand-xyz", bad["output"])
            self.assertNotIn("FromBase64String", bad["output"])  # no wrapper internals leaking
        else:
            self.term("x=41")
            self.assertIn("42", self.term("echo $((x+1))")["output"])
        self.assertEqual(self.term("echo hi")["exit_code"], 0)

    def test_terminal_venv_activation_shows_prefix(self):
        import venv
        venv.create(self.root / "venv", with_pip=False)
        scripts = "Scripts" if shell.IS_WIN else "bin"
        self.assertTrue((self.root / "venv" / scripts).is_dir())
        cmd = "venv/scripts/activate" if shell.IS_WIN else "source venv/bin/activate"
        r = self.term(cmd)
        self.assertTrue(r["prompt"].startswith("(venv) "), r)
        self.assertEqual(r["venv"], "(venv)")
        self.assertTrue(self.term("echo hi")["prompt"].startswith("(venv) "))
        r = self.term("deactivate")
        self.assertFalse(r["prompt"].startswith("("), r)

    @unittest.skipUnless(shell.IS_WIN, "PowerShell-specific activation spellings")
    def test_terminal_venv_activation_spellings(self):
        import venv
        venv.create(self.root / "venv", with_pip=False)
        for cmd in [
            r"venv\Scripts\activate", "venv/scripts/activate", r".\venv\Scripts\activate",
            r"venv\Scripts\activate.bat",            # cmd habit: used to silently do nothing
            r"call venv\Scripts\activate.bat", r"call venv\Scripts\activate",
            "source venv/Scripts/activate", r"venv\Scripts\Activate.ps1", r"& venv\Scripts\Activate.ps1",
            f'"{self.root / "venv" / "Scripts" / "activate.bat"}"',
            r"cd venv\Scripts; activate",             # bare `activate` after cd on one line
        ]:
            shell.reset(self.ws)
            r = self.term(cmd)
            self.assertTrue(r["prompt"].startswith("(venv) "), (cmd, r))
        shell.reset(self.ws)
        self.term(r"cd venv\Scripts")
        self.assertTrue(self.term("activate")["prompt"].startswith("(venv) "))
        self.assertFalse(self.term(r"venv\Scripts\deactivate.bat")["prompt"].startswith("("))
        # typed on separate lines, `.\activate.bat` is mapped too (cwd is known by then)
        shell.reset(self.ws)
        self.term(r"cd venv\Scripts")
        self.assertTrue(self.term(r".\activate.bat")["prompt"].startswith("(venv) "))
        # in a folder without Activate.ps1, `activate` is a plain error, not a crash
        shell.reset(self.ws)
        r = self.term("activate")
        self.assertNotEqual(r["exit_code"], 0)
        self.assertFalse(r["prompt"].startswith("("))

    def test_terminal_interrupt_and_timeout(self):
        # Exercised at the session level (the HTTP view is a thin wrapper) to avoid sharing the
        # in-memory test database with a worker thread.
        import threading
        import time
        s = shell.ShellSession(self.root)
        self.extra_shells.append(s)
        sleeper = "Start-Sleep 30" if shell.IS_WIN else "sleep 30"
        result = {}
        t = threading.Thread(target=lambda: result.update(s.run(sleeper)))
        t0 = time.monotonic()
        t.start()
        time.sleep(1.5)
        s.interrupt()
        t.join(20)
        self.assertFalse(t.is_alive())
        self.assertLess(time.monotonic() - t0, 25)
        self.assertIn("^C", result["output"])
        self.assertIn("hi", s.run("echo hi")["output"])  # a fresh shell took over
        slow = s.run(sleeper, timeout=2)
        self.assertEqual(slow["exit_code"], 124)
        self.assertIn("timed out", slow["output"])
        self.assertIn("hi", s.run("echo hi")["output"])
    # -- real terminal (PTY) ---------------------------------------------------
    def pty(self, **kw):
        s = ptyterm.PtySession(self.root, **kw)
        self.extra_shells.append(s)
        return s

    def wait_for(self, s, text, timeout=20, since=0):
        import time
        deadline = time.monotonic() + timeout
        out = ""
        while time.monotonic() < deadline:
            out = s.read(since, 0.3)["data"]
            if text in out:
                return out
        self.fail(f"{text!r} not seen within {timeout}s; got: {out[-600:]!r}")

    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_runs_commands_and_prompt_is_the_real_folder(self):
        s = self.pty()
        self.wait_for(s, str(self.root.resolve()) + "> ")
        s.write("echo ('pty-' + 'ok')\r")
        self.wait_for(s, "pty-ok")
        (self.root / "sub").mkdir()
        s.write("cd sub; (Get-Location).Path + '!'\r")
        self.wait_for(s, str((self.root / "sub").resolve()) + "!")
        s.write("cd ..\\..; (Get-Location).Path + '?'\r")  # not confined to the workspace
        self.wait_for(s, str(self.root.resolve().parent) + "?")

    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_is_a_real_tty_with_interactive_input(self):
        s = self.pty()
        self.wait_for(s, "> ")
        s.write("python -c \"import sys; print('tty=' + str(sys.stdin.isatty()))\"\r")
        self.wait_for(s, "tty=True")
        s.write("python -c \"n = input('name? '); print('hello-' + n)\"\r")
        self.wait_for(s, "name? ")
        s.write("bob\r")
        self.wait_for(s, "hello-bob")
        s.write("python -c \"import getpass; print('pw-' + getpass.getpass('secret: '))\"\r")
        self.wait_for(s, "secret: ")
        s.write("hunter2\r")
        self.wait_for(s, "pw-hunter2")

    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_ctrl_c_interrupts_running_command(self):
        s = self.pty()
        self.wait_for(s, "> ")
        s.write("Start-Sleep 60\r")
        import time
        time.sleep(1.5)
        s.write("\x03")
        time.sleep(1.0)  # PowerShell redraws after ^C; a human would not type within the same millisecond
        s.write("echo ('af' + 'ter')\r")
        self.wait_for(s, "after", timeout=8)  # would take 60s if the sleep were not interrupted

    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_django_createsuperuser_is_interactive(self):
        import sys
        db = self.root / "t.sqlite3"
        (self.root / "tmp_settings.py").write_text(
            "from pseditor.settings import *\n"
            f"DATABASES = {{'default': {{'ENGINE': 'django.db.backends.sqlite3', 'NAME': r'{db}'}}}}\n")
        proj = Path(__file__).resolve().parent.parent
        s = self.pty()
        self.wait_for(s, "> ")
        s.write(f"$env:PYTHONPATH = '{self.root};{proj}'; $env:DJANGO_SETTINGS_MODULE = 'tmp_settings'\r")
        s.write(f'& "{sys.executable}" "{proj / "manage.py"}" migrate --noinput | Select-Object -Last 1\r')
        self.wait_for(s, "sessions.0001_initial", timeout=60)
        s.write(f'& "{sys.executable}" "{proj / "manage.py"}" createsuperuser\r')
        self.wait_for(s, "Username", timeout=30)
        s.write("boss\r")
        self.wait_for(s, "Email address")
        s.write("boss@example.com\r")
        self.wait_for(s, "Password: ")
        s.write("Tr1cky-Passw0rd-xyz\r")
        self.wait_for(s, "Password (again): ")
        s.write("Tr1cky-Passw0rd-xyz\r")
        out = self.wait_for(s, "Superuser created successfully", timeout=30)
        self.assertNotIn("not running in a TTY", out)

    @unittest.skipUnless(ptyterm.available() and shell.IS_WIN, "PowerShell venv hook")
    def test_pty_venv_activation_spellings_show_prefix(self):
        import venv
        venv.create(self.root / "venv", with_pip=False)
        for cmd in [r"venv\Scripts\activate", "venv/scripts/activate", r".\venv\Scripts\activate",
                    r"venv\Scripts\activate.bat", r"call venv\Scripts\activate.bat",
                    "source venv/Scripts/activate", r"venv\Scripts\Activate.ps1",
                    r"cd venv\Scripts; activate"]:
            s = self.pty()
            self.wait_for(s, "> ")
            s.write(cmd + "\r")
            self.wait_for(s, "(venv)", timeout=15)   # only the prompt prints this (never the typed text)
            s.write("deactivate\r")
        s = self.pty()
        self.wait_for(s, "> ")
        s.write(r"venv\Scripts\activate" + "\r")
        self.wait_for(s, "(venv)")
        s.write(r"venv\Scripts\deactivate.bat" + "\r")
        s.write("echo ('va' + 'r=' + $env:VIRTUAL_ENV + '.')\r")
        self.wait_for(s, "var=.", timeout=10)   # VIRTUAL_ENV is empty again
    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_output_offsets_resize_and_scrollback(self):
        s = self.pty(cols=100, rows=24)
        self.wait_for(s, "> ")
        full = s.read(0)
        self.assertFalse(full["reset"])
        self.assertEqual(s.read(full["end"], 0.2)["data"], "")      # nothing new
        s.write("echo ('of' + 'fset')\r")
        self.wait_for(s, "offset", since=full["end"])
        s.resize(120, 30)
        s.write("$Host.UI.RawUI.WindowSize.Width.ToString() + 'w'\r")
        self.wait_for(s, "120w")
        s._push("x" * (ptyterm.MAX_BUFFER + 10))                    # force a trim
        self.assertTrue(s.read(0)["reset"])
        self.assertLessEqual(len(s.buf), ptyterm.MAX_BUFFER)

    @unittest.skipUnless(ptyterm.available(), "pywinpty / pty not available")
    def test_pty_http_api(self):
        url = f"/api/ws/{self.ws}/pty"
        r = self.j("post", f"{url}/open", {"cols": 90, "rows": 20})
        self.assertEqual(r.status_code, 200)
        sid = r.json()["sid"]
        self.assertEqual(self.j("post", f"{url}/open", {}).json()["sid"], sid)   # reattach
        end = 0
        for _ in range(60):
            d = self.client.get(f"{url}/read", {"sid": sid, "since": end, "wait": 0.5}).json()
            end = d["end"]
            if "> " in d["data"]:
                break
        self.assertIn(str(self.root.resolve()), d["data"])
        self.assertEqual(self.j("post", f"{url}/input", {"sid": sid, "data": "echo ('ht' + 'tp')\r"}).status_code, 200)
        got = ""
        for _ in range(60):
            d = self.client.get(f"{url}/read", {"sid": sid, "since": end, "wait": 0.5}).json()
            end, got = d["end"], got + d["data"]
            if "http" in got:
                break
        self.assertIn("http", got)
        self.assertEqual(self.j("post", f"{url}/resize", {"sid": sid, "cols": 100, "rows": 30}).status_code, 200)
        self.assertEqual(self.client.get(f"{url}/read", {"sid": "stale", "since": 0}).status_code, 409)
        self.assertEqual(self.j("post", f"{url}/input", {"sid": "stale", "data": "x"}).status_code, 409)
        new = self.j("post", f"{url}/open", {"restart": True}).json()["sid"]
        self.assertNotEqual(new, sid)
        self.assertEqual(self.client.get(f"{url}/read", {"sid": sid, "since": 0}).status_code, 409)
        self.assertTrue(self.client.get("/api/bootstrap").json()["pty"])

    @unittest.skipUnless(ptyterm.available() and shell.IS_WIN, "Windows job object")
    def test_pty_shell_dies_with_an_abruptly_killed_server(self):
        import subprocess
        import sys
        import time
        proj = Path(__file__).resolve().parent.parent
        child = (
            "import os, sys, time\n"
            f"sys.path.insert(0, r'{proj}')\n"
            "os.environ['DJANGO_SETTINGS_MODULE'] = 'pseditor.settings'\n"
            "import django; django.setup()\n"
            "from editor import ptyterm\n"
            f"s = ptyterm.PtySession(r'{self.root}')\n"
            "print(s.backend.p.pid, flush=True)\n"
            "time.sleep(60)\n"
        )

        def alive(pid):
            out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True).stdout
            return str(pid) in out

        server = subprocess.Popen([sys.executable, "-c", child], stdout=subprocess.PIPE, text=True)
        shell_pid = int(server.stdout.readline().strip())
        try:
            time.sleep(1.5)
            self.assertTrue(alive(shell_pid))
            subprocess.run(["taskkill", "/F", "/PID", str(server.pid)], capture_output=True)  # no atexit runs
            for _ in range(20):
                time.sleep(0.5)
                if not alive(shell_pid):
                    break
            self.assertFalse(alive(shell_pid), "the shell was orphaned")
        finally:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(shell_pid)], capture_output=True)
            server.stdout.close()

    def test_pty_respects_disabled_setting(self):
        with self.settings(PSEDITOR_ALLOW_TERMINAL=False):
            self.assertEqual(self.j("post", f"/api/ws/{self.ws}/pty/open", {}).status_code, 400)
            self.assertEqual(self.client.get(f"/api/ws/{self.ws}/pty/read", {"sid": "x"}).status_code, 400)

    def test_terminal_disabled_setting(self):
        with self.settings(PSEDITOR_ALLOW_TERMINAL=False):
            r = self.j("post", f"/api/ws/{self.ws}/terminal", {"command": "echo hi"})
            self.assertEqual(r.status_code, 400)

    def test_agent_run_command_stays_confined_to_workspace(self):
        from .fsops import WorkspaceFS
        from .tools import ToolContext
        ctx = ToolContext(WorkspaceFS(self.root))
        ok, _ = ctx.execute("run_command", {"command": "echo hi", "cwd": ".."})
        self.assertFalse(ok)

    # -- agents ------------------------------------------------------------
    def _session(self):
        return self.j("post", f"/api/ws/{self.ws}/sessions").json()["id"]

    def test_agent_validation_and_default(self):
        r = self.j("post", "/api/agents", {"name": "x", "provider": "openai"})
        self.assertEqual(r.status_code, 400)  # model required
        r = self.j("post", "/api/agents", {"name": "a", "provider": "openai", "model": "m", "api_key": "k"})
        self.assertTrue(r.json()["is_default"])
        self.assertNotIn("api_key", r.json())
        self.assertTrue(r.json()["has_key"])

    def test_openrouter_is_seeded_as_default_agent(self):
        from importlib import import_module
        from django.apps import apps as django_apps
        seed = import_module("editor.migrations.0003_default_openrouter_agent").add_openrouter_agent
        seed(django_apps, None)
        agent = Agent.objects.get()
        self.assertEqual((agent.name, agent.base_url, agent.is_default),
                         ("OpenRouter", "https://openrouter.ai/api/v1", True))
        seed(django_apps, None)  # existing agents are left alone
        self.assertEqual(Agent.objects.count(), 1)

        sid = self._session()
        r = self.j("post", f"/api/sessions/{sid}/chat", {"message": "hi"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("OpenRouter API key", r.json()["error"])

    def test_openai_agent_tool_loop_and_revert(self):
        self.j("post", "/api/agents", {"name": "gpt", "provider": "openai", "model": "m",
                                       "base_url": "http://fake/v1", "api_key": "k"})
        sid = self._session()
        replies = [
            {"choices": [{"message": {"content": "Creating file", "tool_calls": [
                {"id": "c1", "type": "function", "function": {
                    "name": "write_file", "arguments": json.dumps({"path": "app.py", "content": "print(1)\n"})}},
                {"id": "c2", "type": "function", "function": {
                    "name": "edit_file", "arguments": json.dumps(
                        {"path": "hello.py", "old_string": "hi", "new_string": "hello"})}},
            ]}}]},
            {"choices": [{"message": {"content": "Done!"}}]},
        ]
        with mock.patch("editor.agents.requests.post", side_effect=[FakeResp(r) for r in replies]) as post:
            resp = self.j("post", f"/api/sessions/{sid}/chat", {"message": "make an app"})
            events = stream_events(resp)
        types = [e["type"] for e in events]
        self.assertIn("tool_call", types)
        self.assertEqual(events[-1]["type"], "done")
        self.assertEqual(sorted(events[-1]["changed"]), ["app.py", "hello.py"])
        self.assertEqual((self.root / "app.py").read_bytes(), b"print(1)\n")
        self.assertEqual((self.root / "hello.py").read_bytes(), b"print('hello')\n")
        # second request must contain tool result messages in OpenAI format
        sent = post.call_args_list[1].kwargs["json"]["messages"]
        self.assertEqual([m["role"] for m in sent][-2:], ["tool", "tool"])
        self.assertEqual(post.call_args_list[0].kwargs["headers"]["Authorization"], "Bearer k")

        detail = self.client.get(f"/api/sessions/{sid}").json()
        user_msg = detail["messages"][0]
        self.assertEqual(sorted(user_msg["changed"]), ["app.py", "hello.py"])
        r = self.j("post", f"/api/messages/{user_msg['id']}/revert")
        self.assertEqual(r.status_code, 200)
        self.assertFalse((self.root / "app.py").exists())
        self.assertEqual((self.root / "hello.py").read_bytes(), b"print('hi')\n")
        self.assertEqual(self.j("post", f"/api/messages/{user_msg['id']}/revert").status_code, 400)

    def test_anthropic_agent(self):
        self.j("post", "/api/agents", {"name": "claude", "provider": "anthropic", "api_key": "k"})
        sid = self._session()
        replies = [
            {"content": [{"type": "text", "text": "ok"},
                         {"type": "tool_use", "id": "t1", "name": "read_file", "input": {"path": "hello.py"}}]},
            {"content": [{"type": "text", "text": "It prints hi."}]},
        ]
        with mock.patch("editor.agents.requests.post", side_effect=[FakeResp(r) for r in replies]) as post:
            events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "what does it do"}))
        self.assertEqual(post.call_args_list[0].args[0], "https://api.anthropic.com/v1/messages")
        second = post.call_args_list[1].kwargs["json"]["messages"]
        self.assertEqual(second[-1]["content"][0]["type"], "tool_result")
        self.assertEqual(events[-1]["type"], "done")
        self.assertEqual([e["content"] for e in events if e["type"] == "text"], ["ok", "It prints hi."])

    def test_webhook_agent(self):
        self.j("post", "/api/agents", {"name": "hook", "provider": "webhook", "base_url": "http://fake/agent"})
        sid = self._session()
        reply = {"reply": "Created it", "actions": [
            {"type": "write_file", "path": "new/dir/x.txt", "content": "data"},
            {"type": "run_command", "command": "echo hi"},
        ]}
        with mock.patch("editor.agents.requests.post", return_value=FakeResp(reply)) as post:
            events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {
                "message": "do it", "active_file": {"path": "hello.py", "selection": "print"}}))
        payload = post.call_args.kwargs["json"]
        self.assertEqual(payload["instruction"], "do it")
        self.assertEqual(payload["active_file"]["content"], "print('hi')\n")
        self.assertEqual((self.root / "new" / "dir" / "x.txt").read_bytes(), b"data")
        self.assertEqual(events[-1]["changed"], ["new/dir/x.txt"])

    def test_cli_agent_detects_changes(self):
        cmd = 'python -c "import sys,pathlib; pathlib.Path(\'out.txt\').write_text(sys.stdin.read()[:5]); print(\'done\')"'
        self.j("post", "/api/agents", {"name": "cli", "provider": "cli", "command": cmd})
        sid = self._session()
        events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "abcdefgh"}))
        self.assertEqual(events[-1]["changed"], ["out.txt"])
        self.assertTrue((self.root / "out.txt").read_text().strip())
        self.assertIn("done", [e["content"] for e in events if e["type"] == "text"][0])

    # -- human in the loop -------------------------------------------------
    def _tool_replies(self, *calls):
        """OpenAI-style replies: one assistant turn with these (name, args) tool calls, then a final answer."""
        tcs = [{"id": f"c{i}", "type": "function", "function": {"name": n, "arguments": json.dumps(a)}}
               for i, (n, a) in enumerate(calls)]
        return [FakeResp({"choices": [{"message": {"content": "working", "tool_calls": tcs}}]}),
                FakeResp({"choices": [{"message": {"content": "finished"}}]})]

    def _gpt(self):
        self.j("post", "/api/agents", {"name": "gpt", "provider": "openai", "model": "m",
                                       "base_url": "http://fake/v1", "api_key": "k"})
        return self._session()

    def _chat(self, sid, replies, human=None, text="go"):
        if human:
            human.start()
        try:
            with mock.patch("editor.agents.requests.post", side_effect=replies) as post:
                events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": text}))
        finally:
            if human:
                human.halt = True
                human.join(2)
        return events, post

    def test_approval_nothing_runs_until_the_user_approves(self):
        sid = self._gpt()
        target = self.root / "app.py"
        existed_when_asked = []
        human = Human(["allow", "allow"], check=lambda a: existed_when_asked.append(target.exists()))
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            events, _ = self._chat(sid, self._tool_replies(
                ("write_file", {"path": "app.py", "content": "print(1)\n"}),
                ("edit_file", {"path": "hello.py", "old_string": "hi", "new_string": "yo"})), human)
        self.assertEqual(existed_when_asked, [False, True])   # 1st: not yet written; 2nd: after 1st was approved
        self.assertEqual([n for n, _ in human.seen], ["write_file", "edit_file"])
        types = [e["type"] for e in events]
        # each approval is requested BEFORE the result of that very action: approval, result, approval, result
        self.assertEqual([t for t in types if t in ("approval", "tool_result")],
                         ["approval", "tool_result", "approval", "tool_result"])
        self.assertEqual([e["decision"] for e in events if e["type"] == "approval_result"], ["allow", "allow"])
        self.assertEqual(target.read_bytes(), b"print(1)\n")
        self.assertEqual((self.root / "hello.py").read_bytes(), b"print('yo')\n")
        self.assertEqual(events[-1]["type"], "done")

    def test_approval_denied_action_is_not_run_and_the_agent_is_told_why(self):
        sid = self._gpt()
        human = Human([("deny", "use hello.py instead"), "allow"])
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            events, post = self._chat(sid, self._tool_replies(
                ("write_file", {"path": "bad.py", "content": "x"}),
                ("run_command", {"command": "echo ran > ran.txt"})), human)
        self.assertFalse((self.root / "bad.py").exists())
        results = [e for e in events if e["type"] == "tool_result"]
        self.assertFalse(results[0]["ok"])
        self.assertIn("denied", results[0]["result"])
        self.assertIn("use hello.py instead", results[0]["result"])
        self.assertTrue(results[1]["ok"])                       # the second action was approved and ran
        self.assertTrue((self.root / "ran.txt").exists())
        sent = post.call_args_list[1].kwargs["json"]["messages"]   # the model sees the denial
        self.assertIn("use hello.py instead", sent[-2]["content"])
        self.assertEqual(events[-1]["type"], "done")
        self.assertEqual(events[-1]["changed"], ["ran.txt"])

    def test_approval_reads_are_free_unless_configured(self):
        sid = self._gpt()
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            events, _ = self._chat(sid, self._tool_replies(("read_file", {"path": "hello.py"}),
                                                           ("list_files", {})), Human([]))
            self.assertNotIn("approval", [e["type"] for e in events])
            self.assertTrue(all(e["ok"] for e in events if e["type"] == "tool_result"))
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True, PSEDITOR_APPROVE_READS=True):
            human = Human(["deny"])
            events, _ = self._chat(sid, self._tool_replies(("read_file", {"path": "hello.py"})), human)
            self.assertEqual([n for n, _ in human.seen], ["read_file"])
            self.assertFalse([e for e in events if e["type"] == "tool_result"][0]["ok"])

    def test_approval_timeout_runs_nothing(self):
        sid = self._gpt()
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True, PSEDITOR_APPROVAL_TIMEOUT=0.3):
            events, _ = self._chat(sid, self._tool_replies(("write_file", {"path": "late.py", "content": "x"})))
        self.assertFalse((self.root / "late.py").exists())
        self.assertEqual(events[-1]["type"], "done")
        errors = [e["message"] for e in events if e["type"] == "error"]
        self.assertTrue(errors and "Timed out" in errors[0])
        self.assertEqual([e["decision"] for e in events if e["type"] == "approval_result"], ["timeout"])
        self.assertEqual(approvals._pending, {})

    def test_approval_stop_releases_the_waiting_action(self):
        sid = self._gpt()
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            events, _ = self._chat(sid, self._tool_replies(("run_command", {"command": "echo hi > x.txt"})),
                                   Human(["stop"]))
        self.assertFalse((self.root / "x.txt").exists())
        self.assertEqual([e["decision"] for e in events if e["type"] == "approval_result"], ["cancelled"])
        self.assertIn("Stopped", [e["message"] for e in events if e["type"] == "error"][0])
        self.assertEqual(approvals._pending, {})

    def test_approval_endpoints(self):
        sid = self._session()
        a = approvals.create(sid, "write_file", {"path": "p"})
        self.assertEqual(self.j("post", f"/api/approvals/{a.id}", {"decision": "maybe"}).status_code, 400)
        self.assertEqual(self.j("post", "/api/approvals/nope", {"decision": "allow"}).status_code, 409)
        r = self.j("post", f"/api/approvals/{a.id}", {"decision": "deny", "reason": "no thanks"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual((a.decision, a.reason), ("deny", "no thanks"))
        self.assertEqual(self.j("post", f"/api/approvals/{a.id}", {"decision": "allow"}).status_code, 409)  # once
        approvals.discard(a.id)   # nobody is waiting on it in this test
        b = approvals.create(sid, "run_command", {"command": "x"})
        self.assertEqual(self.j("post", f"/api/sessions/{sid}/stop").json(), {"released": 1})
        self.assertEqual(approvals.wait(b, 0.1), approvals.CANCELLED)
        self.assertEqual(self.j("post", "/api/sessions/99999/stop").status_code, 404)

    def test_approval_webhook_and_cli_agents_are_gated(self):
        self.j("post", "/api/agents", {"name": "hook", "provider": "webhook", "base_url": "http://fake/agent"})
        sid = self._session()
        reply = {"reply": "done", "actions": [{"type": "write_file", "path": "w.txt", "content": "1"},
                                              {"type": "write_file", "path": "v.txt", "content": "2"}]}
        human = Human(["deny", "allow"])
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            human.start()
            try:
                with mock.patch("editor.agents.requests.post", return_value=FakeResp(reply)):
                    events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "x"}))
            finally:
                human.halt = True
                human.join(2)
        self.assertFalse((self.root / "w.txt").exists())
        self.assertEqual((self.root / "v.txt").read_text(), "2")
        self.assertEqual(events[-1]["changed"], ["v.txt"])

        cmd = 'python -c "import pathlib; pathlib.Path(\'cli_out.txt\').write_text(\'x\')"'
        self.j("post", "/api/agents", {"name": "cli", "provider": "cli", "command": cmd, "is_default": True})
        agent_id = Agent.objects.get(name="cli").pk
        sid = self._session()
        human = Human([("deny", "not now")])
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            human.start()
            try:
                events = stream_events(self.j("post", f"/api/sessions/{sid}/chat",
                                              {"message": "go", "agent_id": agent_id}))
            finally:
                human.halt = True
                human.join(2)
        self.assertEqual([n for n, _ in human.seen], ["cli_agent"])
        self.assertFalse((self.root / "cli_out.txt").exists())
        self.assertIn("not now", [e["content"] for e in events if e["type"] == "text"][0])
        self.assertEqual(events[-1]["changed"], [])

    def test_approval_is_on_by_default(self):
        with self.settings(PSEDITOR_REQUIRE_APPROVAL=True):
            for name in ("write_file", "edit_file", "delete_file", "run_command", "cli_agent", "anything_else"):
                self.assertTrue(approvals.required(name), name)
            for name in ("read_file", "list_files", "search", "workspace_info"):
                self.assertFalse(approvals.required(name), name)
        # the shipped project setting must stay on
        from pseditor import settings as project_settings
        self.assertIs(project_settings.PSEDITOR_REQUIRE_APPROVAL, True)

    def test_openrouter_key_never_sent_to_openai(self):
        # agent created with the OpenAI URL but an OpenRouter key -> corrected on save
        r = self.j("post", "/api/agents", {"name": "or", "provider": "openai", "model": "m",
                                           "base_url": "https://api.openai.com/v1", "api_key": "sk-or-v1-abc"})
        self.assertEqual(r.json()["base_url"], "https://openrouter.ai/api/v1")
        # an already-saved wrong agent is also fixed at request time
        Agent.objects.filter(pk=r.json()["id"]).update(base_url="")
        with mock.patch("editor.agents.requests.get", return_value=FakeResp({"data": []})) as get:
            self.j("post", "/api/models", {"agent_id": r.json()["id"]})
        self.assertEqual(get.call_args.args[0], "https://openrouter.ai/api/v1/models")
        sid = self._session()
        with mock.patch("editor.agents.requests.post",
                        return_value=FakeResp({"choices": [{"message": {"content": "hi"}}]})) as post:
            stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "a"}))
        self.assertEqual(post.call_args.args[0], "https://openrouter.ai/api/v1/chat/completions")

    def test_model_override_per_request(self):
        r = self.j("post", "/api/agents", {"name": "or", "provider": "openai", "model": "default/model",
                                           "base_url": "http://fake/v1"})
        sid = self._session()
        with mock.patch("editor.agents.requests.post",
                        return_value=FakeResp({"choices": [{"message": {"content": "hi"}}]})) as post:
            stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "a", "model": "other/model"}))
            stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "b"}))
        self.assertEqual(post.call_args_list[0].kwargs["json"]["model"], "other/model")
        self.assertEqual(post.call_args_list[1].kwargs["json"]["model"], "default/model")
        self.assertEqual(Agent.objects.get(pk=r.json()["id"]).model, "default/model")

    def test_list_models(self):
        data = {"data": [
            {"id": "b/model", "supported_parameters": ["tools", "temperature"]},
            {"id": "a/no-tools", "supported_parameters": ["temperature"]},
            {"id": "plain"},
        ]}
        with mock.patch("editor.agents.requests.get", return_value=FakeResp(data)) as get:
            r = self.j("post", "/api/models", {"provider": "openai", "base_url": "https://openrouter.ai/api/v1",
                                               "api_key": "k"})
        self.assertEqual(get.call_args.args[0], "https://openrouter.ai/api/v1/models")
        self.assertEqual(get.call_args.kwargs["headers"]["Authorization"], "Bearer k")
        self.assertEqual([(m["id"], m["tools"]) for m in r.json()["models"]],
                         [("a/no-tools", False), ("b/model", True), ("plain", None)])
        # listing models by agent_id alone uses the saved agent's base_url
        ollama = self.j("post", "/api/agents", {"name": "ollama", "provider": "openai",
                                                "base_url": "http://localhost:11434/v1", "model": "qwen2.5-coder:7b"}).json()
        with mock.patch("editor.agents.requests.get", return_value=FakeResp(data)) as get:
            self.j("post", "/api/models", {"agent_id": ollama["id"]})
        self.assertEqual(get.call_args.args[0], "http://localhost:11434/v1/models")
        r = self.j("post", "/api/models", {"provider": "webhook"})
        self.assertEqual(r.status_code, 400)

    def test_agent_http_error_reported(self):
        self.j("post", "/api/agents", {"name": "gpt", "provider": "openai", "model": "m"})
        sid = self._session()
        with mock.patch("editor.agents.requests.post",
                        return_value=FakeResp({"error": {"message": "bad key"}}, 401)):
            events = stream_events(self.j("post", f"/api/sessions/{sid}/chat", {"message": "hi"}))
        err = [e for e in events if e["type"] == "error"][0]
        self.assertIn("bad key", err["message"])
        self.assertEqual(events[-1]["type"], "done")

    def test_agent_tools_cannot_escape_workspace(self):
        from .fsops import WorkspaceFS
        from .tools import ToolContext
        ctx = ToolContext(WorkspaceFS(self.root))
        ok, msg = ctx.execute("write_file", {"path": "../escape.txt", "content": "x"})
        self.assertFalse(ok)
        self.assertFalse((self.root.parent / "escape.txt").exists())
        ok, _ = ctx.execute("edit_file", {"path": "hello.py", "old_string": "nope", "new_string": "x"})
        self.assertFalse(ok)

    def test_add_folder_to_workspace(self):
        other = Path(self.tmp.name) / "other"
        other.mkdir()
        (other / "b.txt").write_bytes(b"bee\n")
        r = self.j("post", f"/api/workspaces/{self.ws}/folders", {"path": str(other)})
        self.assertEqual(r.status_code, 200)
        folders = r.json()["folders"]
        self.assertEqual(len(folders), 2)
        tree = self.client.get(f"/api/ws/{self.ws}/tree").json()["entries"]
        self.assertEqual({e["name"] for e in tree}, {folders[0]["name"], folders[1]["name"]})
        self.assertTrue(all(e.get("root") for e in tree))
        name = folders[1]["name"]
        content = self.client.get(f"/api/ws/{self.ws}/file", {"path": f"{name}/b.txt"}).json()["content"]
        self.assertEqual(content, "bee\n")
        r = self.j("delete", f"/api/workspaces/{self.ws}/folders", {"name": name})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.json()["folders"]), 1)

    def test_model_can_read_write_update_in_added_folder(self):
        from . import agents
        from .fsops import WorkspaceFS
        from .tools import ToolContext
        other = Path(self.tmp.name) / "extra"
        other.mkdir()
        (other / "notes.txt").write_bytes(b"one\n")
        ws = Workspace.objects.get(pk=self.ws)
        ws.add_folder(str(other))
        ws.save()
        fs = WorkspaceFS(folders=ws.get_folders())
        ctx = ToolContext(fs)
        names = [n for n, _ in fs.folders]
        extra = names[1]

        ok, info = ctx.execute("workspace_info", {})
        self.assertTrue(ok)
        self.assertIn(str(other.resolve()), info)
        self.assertIn(f"{extra}/", info)

        ok, text = ctx.execute("read_file", {"path": f"{extra}/notes.txt"})
        self.assertTrue(ok)
        self.assertEqual(text, "one\n")
        ok, _ = ctx.execute("write_file", {"path": f"{extra}/new/created.txt", "content": "hi"})
        self.assertTrue(ok)
        self.assertEqual((other / "new" / "created.txt").read_text(), "hi")
        ok, _ = ctx.execute("edit_file", {"path": f"{extra}/notes.txt", "old_string": "one", "new_string": "two"})
        self.assertTrue(ok)
        self.assertEqual((other / "notes.txt").read_text(), "two\n")
        # still confined to the added folders
        ok, _ = ctx.execute("write_file", {"path": f"{extra}/../../escape.txt", "content": "x"})
        self.assertFalse(ok)

        agent = Agent(name="t", provider=Agent.OPENAI, model="m")
        prompt = agents.build_system_prompt(agent, fs)
        self.assertIn(str(other.resolve()), prompt)
        self.assertIn(str(self.root.resolve()), prompt)
        self.assertIn(str(other.resolve()), agents.build_context(fs))

    def test_single_folder_workspace_info(self):
        from .fsops import WorkspaceFS
        from .tools import ToolContext
        ok, info = ToolContext(WorkspaceFS(self.root)).execute("workspace_info", {})
        self.assertTrue(ok)
        self.assertIn(str(self.root.resolve()), info)
