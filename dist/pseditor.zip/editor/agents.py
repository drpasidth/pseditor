"""Connectors for external agents and the tool-calling loop that drives them."""
import json
import os
import re
import shlex
import shutil
import sys
import uuid

import requests
from django.conf import settings

from . import approvals
from .fsops import FsError, run_process
from .models import Agent, ChatMessage
from .tools import TOOL_SPECS, ToolContext

HTTP_TIMEOUT = 300
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

DEFAULT_SYSTEM_PROMPT = """You are the coding agent inside PSEditor, a code editor similar to Cursor.
You work on the user's workspace through tools: workspace_info, list_files, read_file, search, write_file, edit_file, delete_file and run_command.
The workspace is the set of folders the user has added to it; you can read, create, update and delete files inside those folders only.
The user can add more folders at any time, so call workspace_info if you are unsure which folders are available.

Guidelines:
- Read relevant files before changing them. Paths are relative to the workspace root.
- Prefer edit_file for small, targeted changes; use write_file for new files or full rewrites.
- Make the changes the user asked for directly with tools instead of only describing them.
- After changing code, verify it when practical (run tests or the program with run_command).
- Every write_file, edit_file, delete_file and run_command is shown to the user, who must approve it before it runs. If an action is denied, do not retry it unchanged: take the user's reason into account, try a different approach, or ask what they want.
- Keep final answers short: say what you changed and anything the user must do next.
Operating system of the host: {os}.{multi}"""

MULTI_ROOT_NOTE = """
This workspace has multiple root folders. File paths use the form RootName/relative/path
(for example myapp/src/main.py). list_files shows all roots; run_command cwd may be a root name."""


class AgentError(Exception):
    pass


class Cancelled(Exception):
    """The user pressed Stop while an action was waiting for approval."""


def _ask(session, call_id, name, args):
    """Generator: ask the user before an action runs. Returns (allowed, note) through ``yield from``.

    Yields an ``approval`` event, then blocks until the browser answers. Raises Cancelled on Stop and
    AgentError on timeout, so an unanswered action is never executed.
    """
    if not approvals.required(name):
        return True, ""
    a = approvals.create(session.id, name, args)
    try:
        yield {"type": "approval", "id": a.id, "tool_id": call_id, "name": name, "arguments": args}
        decision = approvals.wait(a)
    finally:
        approvals.discard(a.id)  # also runs when the client disconnects mid-wait
    yield {"type": "approval_result", "id": a.id, "tool_id": call_id, "decision": decision}
    if decision == approvals.ALLOW:
        return True, ""
    if decision == approvals.DENY:
        return False, a.reason
    if decision == approvals.CANCELLED:
        raise Cancelled()
    raise AgentError("Timed out waiting for your approval, so nothing was run. Send a message to try again.")


def _denied_text(note):
    text = "The user denied this action, so it was NOT run."
    if note:
        text += f" Reason given by the user: {note}"
    return text + " Do not repeat it unchanged; adapt, try something else, or ask the user what they want."


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def build_system_prompt(agent, fs=None):
    multi = MULTI_ROOT_NOTE if fs is not None and getattr(fs, "multi", False) else ""
    base = DEFAULT_SYSTEM_PROMPT.format(
        os="Windows" if sys.platform == "win32" else sys.platform,
        multi=multi,
    )
    if fs is not None:
        base += "\n\nWorkspace folders:\n" + describe_folders(fs)
    if agent.system_prompt.strip():
        base += "\n\nAdditional instructions from the user:\n" + agent.system_prompt.strip()
    return base


def describe_folders(fs):
    """One line per workspace folder: how to address it and where it lives on disk."""
    if getattr(fs, "multi", False):
        return "\n".join(f"- {n}/  ->  {p}" for n, p in fs.folders)
    return "\n".join(f"- (workspace root)  ->  {p}" for _, p in fs.folders)


def build_context(fs, active=None):
    """Context appended to the user's message: open file, selection, file list."""
    parts = ["Workspace folders (the model can read/write inside these):\n" + describe_folders(fs)]
    files = fs.list_files(limit=200)
    if files:
        parts.append("Workspace files (first %d):\n%s" % (len(files), "\n".join(files)))
    if active and active.get("path"):
        block = f"Currently open file: {active['path']}"
        sel = (active.get("selection") or "").strip()
        if sel:
            block += f"\nSelected text:\n```\n{sel[:6000]}\n```"
        parts.append(block)
    return "\n\n<context>\n" + "\n\n".join(parts) + "\n</context>" if parts else ""


def load_history(session, limit=60):
    rows = list(session.messages.order_by("-id")[:limit])[::-1]
    msgs = [r.data() for r in rows if r.role in ("user", "assistant", "tool")]
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    return msgs


def _save(session, msg):
    return ChatMessage.objects.create(session=session, role=msg["role"], payload=json.dumps(msg))


def _http_error(resp):
    try:
        body = resp.json()
        detail = body.get("error", body)
        if isinstance(detail, dict):
            detail = detail.get("message", detail)
    except ValueError:
        detail = resp.text[:500]
    return AgentError(f"HTTP {resp.status_code}: {detail}")


def _post(url, headers, payload):
    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=HTTP_TIMEOUT)
    except requests.RequestException as exc:
        raise AgentError(f"Cannot reach agent at {url}: {exc}")
    if resp.status_code >= 400:
        raise _http_error(resp)
    return resp


def _parse_args(raw):
    if isinstance(raw, dict):
        return raw
    try:
        data = json.loads(raw or "{}")
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


# ---------------------------------------------------------------------------
# OpenAI-compatible
# ---------------------------------------------------------------------------
OPENROUTER_URL = "https://openrouter.ai/api/v1"


def resolve_openai_base(base_url, api_key):
    """Default the base URL; OpenRouter keys (sk-or-...) never belong on api.openai.com."""
    base = (base_url or "").strip().rstrip("/")
    if (api_key or "").startswith("sk-or-") and (not base or "api.openai.com" in base):
        return OPENROUTER_URL
    return base or "https://api.openai.com/v1"


def _openai_url(agent):
    base = resolve_openai_base(agent.base_url, agent.api_key).rstrip("/")
    return base if base.endswith("/chat/completions") else base + "/chat/completions"


def _to_openai(system, messages):
    out = [{"role": "system", "content": system}]
    for m in messages:
        if m["role"] == "user":
            out.append({"role": "user", "content": m["content"]})
        elif m["role"] == "assistant":
            d = {"role": "assistant", "content": m.get("content") or None}
            if m.get("tool_calls"):
                d["tool_calls"] = [{
                    "id": tc["id"], "type": "function",
                    "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])},
                } for tc in m["tool_calls"]]
            out.append(d)
        elif m["role"] == "tool":
            out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
    return out


def call_openai(agent, system, messages, use_tools=True):
    headers = {"Content-Type": "application/json", **agent.headers()}
    if agent.api_key:
        headers["Authorization"] = f"Bearer {agent.api_key}"
    payload = {"model": agent.model, "messages": _to_openai(system, messages)}
    if agent.temperature is not None:
        payload["temperature"] = agent.temperature
    if use_tools:
        payload["tools"] = [{"type": "function", "function": t} for t in TOOL_SPECS]
        payload["tool_choice"] = "auto"
    data = _post(_openai_url(agent), headers, payload).json()
    try:
        msg = data["choices"][0]["message"]
    except (KeyError, IndexError, TypeError):
        raise AgentError(f"Unexpected response: {str(data)[:300]}")
    calls = []
    for tc in msg.get("tool_calls") or []:
        fn = tc.get("function", {})
        calls.append({
            "id": tc.get("id") or "call_" + uuid.uuid4().hex[:12],
            "name": fn.get("name", ""),
            "arguments": _parse_args(fn.get("arguments")),
        })
    return {"content": msg.get("content") or "", "tool_calls": calls}


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------
def _anthropic_url(agent):
    base = (agent.base_url or "https://api.anthropic.com").rstrip("/")
    if base.endswith("/messages"):
        return base
    if base.endswith("/v1"):
        return base + "/messages"
    return base + "/v1/messages"


def _to_anthropic(messages):
    out = []

    def push(role, blocks):
        if out and out[-1]["role"] == role:
            out[-1]["content"].extend(blocks)
        else:
            out.append({"role": role, "content": blocks})

    for m in messages:
        if m["role"] == "user":
            push("user", [{"type": "text", "text": m["content"] or "(empty)"}])
        elif m["role"] == "assistant":
            blocks = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for tc in m.get("tool_calls") or []:
                blocks.append({"type": "tool_use", "id": tc["id"], "name": tc["name"],
                               "input": tc["arguments"]})
            if blocks:
                push("assistant", blocks)
        elif m["role"] == "tool":
            push("user", [{"type": "tool_result", "tool_use_id": m["tool_call_id"],
                           "content": m["content"] or "(empty)"}])
    return out


def call_anthropic(agent, system, messages, use_tools=True):
    headers = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key": agent.api_key,
        **agent.headers(),
    }
    payload = {
        "model": agent.model or "claude-sonnet-4-5",
        "max_tokens": 8192,
        "system": system,
        "messages": _to_anthropic(messages),
    }
    if agent.temperature is not None:
        payload["temperature"] = agent.temperature
    if use_tools:
        payload["tools"] = [
            {"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
            for t in TOOL_SPECS
        ]
    data = _post(_anthropic_url(agent), headers, payload).json()
    text, calls = [], []
    for block in data.get("content", []):
        if block.get("type") == "text":
            text.append(block.get("text", ""))
        elif block.get("type") == "tool_use":
            calls.append({"id": block["id"], "name": block["name"], "arguments": block.get("input") or {}})
    return {"content": "".join(text), "tool_calls": calls}


# ---------------------------------------------------------------------------
# Webhook & CLI agents
# ---------------------------------------------------------------------------
def call_webhook(agent, fs, instruction, history, active):
    """POST the task to a custom HTTP agent.

    Request JSON: instruction, messages[{role,content}], system_prompt, model, workspace{name,path},
                  files[], active_file{path,selection,content}
    Response JSON: {"reply": str, "actions": [{"type": "write_file"|"edit_file"|"delete_file"|
                    "run_command", ...tool arguments...}]}
    """
    if not agent.base_url:
        raise AgentError("Webhook URL is not configured.")
    headers = {"Content-Type": "application/json", **agent.headers()}
    if agent.api_key:
        headers["Authorization"] = f"Bearer {agent.api_key}"
    active_payload = None
    if active and active.get("path"):
        active_payload = dict(active)
        try:
            active_payload["content"] = fs.read(active["path"])[:60000]
        except FsError:
            pass
    payload = {
        "instruction": instruction,
        "messages": [
            {"role": m["role"], "content": m.get("display", m["content"]) if m["role"] == "user" else m["content"]}
            for m in history if m["role"] in ("user", "assistant") and m.get("content")
        ],
        "system_prompt": build_system_prompt(agent, fs),
        "model": agent.model,
        "workspace": {
            "name": fs.root.name,
            "path": str(fs.root),
            "folders": [{"name": n, "path": str(p)} for n, p in fs.folders],
        },
        "files": fs.list_files(limit=500),
        "active_file": active_payload,
    }
    resp = _post(agent.base_url, headers, payload)
    try:
        data = resp.json()
    except ValueError:
        return {"reply": resp.text, "actions": []}
    if not isinstance(data, dict):
        return {"reply": str(data), "actions": []}
    return {
        "reply": data.get("reply") or data.get("message") or data.get("content") or "",
        "actions": data.get("actions") or [],
    }


def _cli_prompt(agent, history, instruction, context):
    parts = []
    if agent.system_prompt.strip():
        parts.append(agent.system_prompt.strip())
    turns = [m for m in history[:-1] if m["role"] in ("user", "assistant") and m.get("content")][-8:]
    if turns:
        convo = []
        for m in turns:
            who = "User" if m["role"] == "user" else "Assistant"
            convo.append(f"{who}: {m.get('display', m['content']) if m['role'] == 'user' else m['content']}")
        parts.append("Earlier conversation:\n" + "\n".join(convo))
    parts.append(instruction + context)
    return "\n\n".join(parts)


def call_cli(agent, fs, prompt):
    cmd = agent.command.strip()
    if not cmd:
        raise AgentError("No command configured for this agent.")
    timeout = getattr(settings, "PSEDITOR_CLI_TIMEOUT", 900)
    if "{prompt}" in cmd:
        posix = os.name != "nt"
        args = shlex.split(cmd, posix=posix)
        if not posix:
            args = [a[1:-1] if len(a) > 1 and a[0] == a[-1] and a[0] in "\"'" else a for a in args]
        exe = shutil.which(args[0])
        if exe:
            args[0] = exe
        flat = exe and exe.lower().endswith((".cmd", ".bat"))
        value = prompt.replace("\r", "").replace("\n", " ") if flat else prompt
        args = [a.replace("{prompt}", value) for a in args]
        code, out = run_process(args, fs.root, timeout, shell=False)
    else:
        code, out = run_process(cmd, fs.root, timeout, shell=True, stdin=prompt)
    out = ANSI_RE.sub("", out).strip()
    if code != 0:
        out = (out + f"\n\n[exit code {code}]").strip()
    return out or "(agent produced no output)"


# ---------------------------------------------------------------------------
# model listing
# ---------------------------------------------------------------------------
def list_models(provider, base_url, api_key, extra_headers=None):
    """Return [{"id": str, "tools": True|False|None}] from the provider's /models endpoint."""
    headers = dict(extra_headers or {})
    if provider == Agent.OPENAI:
        base = resolve_openai_base(base_url, api_key).rstrip("/")
        if base.endswith("/chat/completions"):
            base = base[: -len("/chat/completions")]
        url = base + "/models"
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
    elif provider == Agent.ANTHROPIC:
        base = (base_url or "https://api.anthropic.com").rstrip("/")
        url = base + ("/models" if base.endswith("/v1") else "/v1/models")
        headers.update({"x-api-key": api_key, "anthropic-version": "2023-06-01"})
    else:
        raise AgentError("Model listing is only available for OpenAI-compatible and Anthropic agents.")
    try:
        resp = requests.get(url, headers=headers, params={"limit": 1000} if provider == Agent.ANTHROPIC else None,
                            timeout=30)
    except requests.RequestException as exc:
        raise AgentError(f"Cannot reach {url}: {exc}")
    if resp.status_code >= 400:
        raise _http_error(resp)
    try:
        items = resp.json().get("data", [])
    except (ValueError, AttributeError):
        raise AgentError("The provider did not return a JSON model list.")
    out = []
    for m in items:
        if not isinstance(m, dict) or not m.get("id"):
            continue
        params = m.get("supported_parameters")  # OpenRouter reports tool support here
        tools = ("tools" in params) if isinstance(params, list) else None
        out.append({"id": m["id"], "tools": tools})
    out.sort(key=lambda x: x["id"])
    return out


# ---------------------------------------------------------------------------
# connection test
# ---------------------------------------------------------------------------
def test_agent(agent):
    """Return (ok, message)."""
    try:
        if agent.provider == Agent.OPENAI:
            r = call_openai(agent, "You are a test.", [{"role": "user", "content": "Reply with: OK"}], use_tools=False)
            return True, f"Connected. Model replied: {r['content'][:80]!r}"
        if agent.provider == Agent.ANTHROPIC:
            r = call_anthropic(agent, "You are a test.", [{"role": "user", "content": "Reply with: OK"}], use_tools=False)
            return True, f"Connected. Model replied: {r['content'][:80]!r}"
        if agent.provider == Agent.WEBHOOK:
            if not agent.base_url:
                return False, "Webhook URL is empty."
            headers = {"Content-Type": "application/json", **agent.headers()}
            if agent.api_key:
                headers["Authorization"] = f"Bearer {agent.api_key}"
            _post(agent.base_url, headers, {"instruction": "ping", "ping": True, "messages": [],
                                           "files": [], "workspace": {}})
            return True, "Webhook responded."
        if agent.provider == Agent.CLI:
            parts = shlex.split(agent.command, posix=os.name != "nt") if agent.command.strip() else []
            if not parts:
                return False, "Command is empty."
            exe = shutil.which(parts[0].strip("\"'"))
            return (True, f"Found executable: {exe}") if exe else (False, f"'{parts[0]}' was not found on PATH.")
    except AgentError as exc:
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001
        return False, f"Error: {exc}"
    return False, "Unknown provider."


# ---------------------------------------------------------------------------
# the agent turn
# ---------------------------------------------------------------------------
def run_turn(session, agent, fs, text, active=None):
    """Generator of event dicts. Persists messages and an undo checkpoint."""
    ctx = ToolContext(fs)
    context = build_context(fs, active)
    history = load_history(session)
    user_msg = {"role": "user", "content": text + context, "display": text}
    user_row = _save(session, user_msg)
    history.append(user_msg)
    if session.title == "New chat":
        session.title = text.strip().splitlines()[0][:60] or "New chat"
    session.agent = agent
    session.save()

    yield {"type": "start", "message_id": user_row.id}
    try:
        if agent.provider in (Agent.OPENAI, Agent.ANTHROPIC):
            yield from _tool_loop(session, agent, ctx, history, fs=fs)
        elif agent.provider == Agent.WEBHOOK:
            yield from _webhook_turn(session, agent, fs, ctx, history, text, active)
        elif agent.provider == Agent.CLI:
            yield from _cli_turn(session, agent, fs, ctx, history, text, context)
        else:
            raise AgentError(f"Unknown provider {agent.provider}")
    except Cancelled:
        yield {"type": "error", "message": "Stopped while waiting for approval. Nothing more was run."}
    except AgentError as exc:
        yield {"type": "error", "message": str(exc)}
    except GeneratorExit:
        raise
    except Exception as exc:  # noqa: BLE001
        yield {"type": "error", "message": f"Unexpected error: {exc}"}
    finally:
        if ctx.checkpoint:
            user_row.checkpoint = ctx.checkpoint_json()
            user_row.save(update_fields=["checkpoint"])
    if ctx.changed:
        yield {"type": "files_changed", "paths": ctx.changed}
    yield {"type": "done", "message_id": user_row.id, "changed": ctx.changed, "title": session.title}


def _tool_loop(session, agent, ctx, history, fs=None):
    system = build_system_prompt(agent, fs)
    caller = call_openai if agent.provider == Agent.OPENAI else call_anthropic
    max_steps = getattr(settings, "PSEDITOR_MAX_AGENT_STEPS", 25)
    for _ in range(max_steps):
        reply = caller(agent, system, history)
        assistant = {"role": "assistant", "content": reply["content"], "tool_calls": reply["tool_calls"]}
        if reply["content"]:
            yield {"type": "text", "content": reply["content"]}
        if not reply["tool_calls"]:
            history.append(assistant)
            _save(session, assistant)
            return
        results = []
        for tc in reply["tool_calls"]:
            yield {"type": "tool_call", "id": tc["id"], "name": tc["name"], "arguments": tc["arguments"]}
            allowed, note = yield from _ask(session, tc["id"], tc["name"], tc["arguments"])
            if allowed:
                ok, result = ctx.execute(tc["name"], tc["arguments"])
            else:
                ok, result = False, _denied_text(note)
            yield {"type": "tool_result", "id": tc["id"], "name": tc["name"], "ok": ok,
                   "result": result[:4000], "changed": list(ctx.changed)}
            results.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"], "content": result})
        history.append(assistant)
        history.extend(results)
        _save(session, assistant)
        for r in results:
            _save(session, r)
    note = {"role": "assistant", "content": f"(Stopped after {max_steps} steps. Send a message to continue.)"}
    history.append(note)
    _save(session, note)
    yield {"type": "text", "content": note["content"]}


def _webhook_turn(session, agent, fs, ctx, history, text, active):
    data = call_webhook(agent, fs, text, history, active)
    for i, action in enumerate(data["actions"]):
        if not isinstance(action, dict):
            continue
        name = action.get("type") or action.get("action") or ""
        args = {k: v for k, v in action.items() if k not in ("type", "action")}
        cid = f"act_{i}"
        yield {"type": "tool_call", "id": cid, "name": name, "arguments": args}
        allowed, note = yield from _ask(session, cid, name, args)
        if allowed:
            ok, result = ctx.execute(name, args)
        else:
            ok, result = False, _denied_text(note)
        yield {"type": "tool_result", "id": cid, "name": name, "ok": ok, "result": result[:4000],
               "changed": list(ctx.changed)}
    reply = {"role": "assistant", "content": data["reply"]}
    history.append(reply)
    _save(session, reply)
    if data["reply"]:
        yield {"type": "text", "content": data["reply"]}


def _cli_turn(session, agent, fs, ctx, history, text, context):
    prompt = _cli_prompt(agent, history, text, context)
    before = fs.snapshot()
    args = {"command": agent.command, "prompt": prompt[:3000]}
    yield {"type": "tool_call", "id": "cli", "name": "cli_agent", "arguments": args}
    # A CLI agent edits files by itself and cannot be interrupted per action, so approve the whole run up front.
    allowed, note = yield from _ask(session, "cli", "cli_agent", args)
    if not allowed:
        msg = "Not run: you denied this command-line agent." + (f" Reason: {note}" if note else "")
        yield {"type": "tool_result", "id": "cli", "name": "cli_agent", "ok": False, "result": msg,
               "changed": []}
        reply = {"role": "assistant", "content": msg}
        history.append(reply)
        _save(session, reply)
        yield {"type": "text", "content": msg}
        return
    out = call_cli(agent, fs, prompt)
    ctx.absorb_snapshot_diff(before, fs.snapshot())
    yield {"type": "tool_result", "id": "cli", "name": "cli_agent", "ok": True,
           "result": f"finished; {len(ctx.changed)} file(s) changed", "changed": list(ctx.changed)}
    reply = {"role": "assistant", "content": out}
    history.append(reply)
    _save(session, reply)
    yield {"type": "text", "content": out}
