#!/bin/bash
# Start PSEditor on macOS. Double-click in Finder, or run: bash run_mac.command
cd "$(dirname "$0")" || exit 1

if [ -x ".venv/bin/python" ]; then
  PY=".venv/bin/python"
elif [ -x "venv/bin/python" ]; then
  PY="venv/bin/python"
else
  echo "PSEditor is not installed yet. Double-click install_mac.command first."
  read -r -p "Press Enter to close" _
  exit 1
fi

echo "Using: $PY"
if ! "$PY" manage.py migrate --noinput; then
  echo "Migration failed."
  read -r -p "Press Enter to close" _
  exit 1
fi

# Open the browser after a short delay so the first page load hits a live server
(sleep 2 && open "http://127.0.0.1:8800/") &

echo
echo "PSEditor running at http://127.0.0.1:8800/"
echo "Press Ctrl+C to stop."
echo
"$PY" manage.py runserver 127.0.0.1:8800
